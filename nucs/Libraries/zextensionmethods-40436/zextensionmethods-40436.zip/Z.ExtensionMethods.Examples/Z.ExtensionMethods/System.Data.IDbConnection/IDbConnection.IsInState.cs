using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class System_Data_IDbConnection_IsInState
    {
        [TestMethod]
        public void IsInState()
        {
            //// Examples
            //using (var conn = new SqlConnection(My.Config.ConnectionString.UnitTest.ConnectionString))
            //{
            //    bool result1 = conn.IsInState(ConnectionState.Open); // return false;
            //    conn.Open();
            //    bool result2 = conn.IsInState(ConnectionState.Open); // return true;

            //    // UnitTest
            //    Assert.IsFalse(result1);
            //    Assert.IsTrue(result2);
            //}
        }
    }
}
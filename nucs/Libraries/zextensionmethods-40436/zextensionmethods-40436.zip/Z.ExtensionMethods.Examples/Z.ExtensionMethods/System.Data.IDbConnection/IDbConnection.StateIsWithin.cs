using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class System_Data_IDbConnection_StateIsWithin
    {
        [TestMethod]
        public void StateIsWithin()
        {
            //// Examples
            //using (var conn = new SqlConnection(My.Config.ConnectionString.UnitTest.ConnectionString))
            //{
            //    bool result1 = conn.StateIsWithin(ConnectionState.Executing, ConnectionState.Open); // return false;
            //    conn.Open();
            //    bool result2 = conn.StateIsWithin(ConnectionState.Executing, ConnectionState.Open); // return true;

            //    // UnitTest
            //    Assert.IsFalse(result1);
            //    Assert.IsTrue(result2);
            //}
        }
    }
}
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class System_EventHandler_RaiseEvent
    {
        [TestMethod]
        public void RaiseEvent()
        {
            //// Type
            //var @this = null;

            //// Exemples
            //var result = @this.RaiseEvent(); // result = ";

            //// Unit Test
            //Assert.Fail("Not implemented");
        }
    }
}
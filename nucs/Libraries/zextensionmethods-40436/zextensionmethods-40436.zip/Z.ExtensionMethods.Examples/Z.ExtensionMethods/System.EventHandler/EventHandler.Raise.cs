using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class System_EventHandler_Raise
    {
        [TestMethod]
        public void Raise()
        {
            //// Type
            //var @this = null;

            //// Exemples
            //var result = @this.Raise(); // result = ";

            //// Unit Test
            //Assert.Fail("Not implemented");
        }
    }
}
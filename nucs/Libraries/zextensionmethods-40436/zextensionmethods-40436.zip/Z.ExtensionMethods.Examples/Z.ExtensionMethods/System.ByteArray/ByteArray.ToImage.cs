using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class System_ByteArray_ToImage
    {
        [TestMethod]
        public void ToImage()
        {
            // Type
            var @this = new Byte[1] {1};

            // Exemples
            // Image result = @this.ToImage(); // return an image

            // Unit Test
        }
    }
}
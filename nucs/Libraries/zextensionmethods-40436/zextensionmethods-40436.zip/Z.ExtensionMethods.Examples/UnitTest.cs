using System;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Z.ExtensionMethods;

namespace Z.ExtensionMethods.Object.Test
{
    // Keep it for testing purspose
}

namespace ExtensionMethods.Examples
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void Test()
        {
            string path = @"C:\Users\Jonathan\Desktop\CompressionTest\abc.txt";
            //path.ToFileInfo().CreateZip(@"C:\Users\Jonathan\Desktop\CompressionTest\abc.txtsss.zip");
            //int ac;
            //Int32.TryParse("", out ac);
            //char a = CultureInfo.CurrentUICulture.NumberFormat.NumberDecimalSeparator[0];
            //char b = a;
            // var a = new object();

            // object a = "1";
            // var b = (int?) a;

            // int[] z = new int[3];
            //z.ClearAt();


            //Dictionary<string, string> abc = new Dictionary<string, string>();
            // var d = abc.ToList();

            // d.RemoveAt();
            // ICollection<string> c = (ICollection<string>) d;


            //// Examples
            //using (var conn = new SqlConnection(My.Config.ConnectionString.UnitTest.ConnectionString))
            //{
            //    conn.State.NotIn()
            //    using (SqlCommand @this = conn.CreateCommand())
            //    {
            //        @this.Parameters.Add();
            //        @this.Parameters.AddWithValue()
            //        conn.Open();
            //        var result = @this.ExecuteReader();
            //        while (result.Read())
            //        {
            //            result.NextResult();
            //        }
            //    }
            //}
        }
    }
}
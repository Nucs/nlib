using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

/// <summary>
/// Finds a resource within the project.
/// </summary>
internal class ResourceFinder
{
}

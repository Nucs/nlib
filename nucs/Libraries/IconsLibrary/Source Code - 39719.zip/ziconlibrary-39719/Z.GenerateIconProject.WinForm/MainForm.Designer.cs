﻿namespace Z.GenerateIconProject.WinForm
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.uiSyncMessage = new System.Windows.Forms.Label();
            this.uiSyncIconHelp = new System.Windows.Forms.Label();
            this.uiSynchronize = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.uiSyncSourceDirectoryPath = new System.Windows.Forms.TextBox();
            this.uiSyncWithDirectoryPath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.uiGenerateMessage = new System.Windows.Forms.Label();
            this.uiGenerateHelp = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.uiGenerateNamespace = new System.Windows.Forms.TextBox();
            this.uiGenerateIcon16Path = new System.Windows.Forms.TextBox();
            this.uiGenerateIcon32Path = new System.Windows.Forms.TextBox();
            this.uiGenerateCssFileName = new System.Windows.Forms.TextBox();
            this.uiGenerateIsCssImportant = new System.Windows.Forms.CheckBox();
            this.uiGenerateHandlerPath = new System.Windows.Forms.TextBox();
            this.uiGenerate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.uiWorkingDirectoryHelp = new System.Windows.Forms.Label();
            this.uiWorkingDirectoryMessage = new System.Windows.Forms.Label();
            this.uiWorkingDirectoryValidate = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.uiWorkingDirectoryPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.uiReset = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.uiSyncMessage);
            this.groupBox3.Controls.Add(this.uiSyncIconHelp);
            this.groupBox3.Controls.Add(this.uiSynchronize);
            this.groupBox3.Controls.Add(this.tableLayoutPanel2);
            this.groupBox3.Location = new System.Drawing.Point(12, 152);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(559, 148);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sync Icon";
            // 
            // uiSyncMessage
            // 
            this.uiSyncMessage.AutoSize = true;
            this.uiSyncMessage.Location = new System.Drawing.Point(4, 125);
            this.uiSyncMessage.Name = "uiSyncMessage";
            this.uiSyncMessage.Size = new System.Drawing.Size(88, 13);
            this.uiSyncMessage.TabIndex = 5;
            this.uiSyncMessage.Text = "[uiSyncMessage]";
            // 
            // uiSyncIconHelp
            // 
            this.uiSyncIconHelp.AutoSize = true;
            this.uiSyncIconHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiSyncIconHelp.Location = new System.Drawing.Point(4, 16);
            this.uiSyncIconHelp.Name = "uiSyncIconHelp";
            this.uiSyncIconHelp.Size = new System.Drawing.Size(113, 17);
            this.uiSyncIconHelp.TabIndex = 4;
            this.uiSyncIconHelp.Text = "[uiSyncIconHelp]";
            // 
            // uiSynchronize
            // 
            this.uiSynchronize.Location = new System.Drawing.Point(478, 115);
            this.uiSynchronize.Name = "uiSynchronize";
            this.uiSynchronize.Size = new System.Drawing.Size(75, 23);
            this.uiSynchronize.TabIndex = 1;
            this.uiSynchronize.Text = "Synchronize";
            this.uiSynchronize.UseVisualStyleBackColor = true;
            this.uiSynchronize.Click += new System.EventHandler(this.uiSynchronize_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 446F));
            this.tableLayoutPanel2.Controls.Add(this.uiSyncSourceDirectoryPath, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.uiSyncWithDirectoryPath, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(7, 61);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(546, 50);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // uiSyncSourceDirectoryPath
            // 
            this.uiSyncSourceDirectoryPath.Location = new System.Drawing.Point(128, 3);
            this.uiSyncSourceDirectoryPath.Name = "uiSyncSourceDirectoryPath";
            this.uiSyncSourceDirectoryPath.Size = new System.Drawing.Size(440, 20);
            this.uiSyncSourceDirectoryPath.TabIndex = 3;
            // 
            // uiSyncWithDirectoryPath
            // 
            this.uiSyncWithDirectoryPath.Location = new System.Drawing.Point(128, 28);
            this.uiSyncWithDirectoryPath.Name = "uiSyncWithDirectoryPath";
            this.uiSyncWithDirectoryPath.Size = new System.Drawing.Size(440, 20);
            this.uiSyncWithDirectoryPath.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Icon32:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "FatCow_Icons16x16";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.uiReset);
            this.groupBox2.Controls.Add(this.uiGenerateMessage);
            this.groupBox2.Controls.Add(this.uiGenerateHelp);
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Controls.Add(this.uiGenerate);
            this.groupBox2.Location = new System.Drawing.Point(12, 316);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(559, 227);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Generate File";
            // 
            // uiGenerateMessage
            // 
            this.uiGenerateMessage.AutoSize = true;
            this.uiGenerateMessage.Location = new System.Drawing.Point(4, 205);
            this.uiGenerateMessage.Name = "uiGenerateMessage";
            this.uiGenerateMessage.Size = new System.Drawing.Size(108, 13);
            this.uiGenerateMessage.TabIndex = 6;
            this.uiGenerateMessage.Text = "[uiGenerateMessage]";
            // 
            // uiGenerateHelp
            // 
            this.uiGenerateHelp.AutoSize = true;
            this.uiGenerateHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiGenerateHelp.Location = new System.Drawing.Point(4, 16);
            this.uiGenerateHelp.Name = "uiGenerateHelp";
            this.uiGenerateHelp.Size = new System.Drawing.Size(116, 17);
            this.uiGenerateHelp.TabIndex = 5;
            this.uiGenerateHelp.Text = "[uiGenerateHelp]";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 419F));
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.Label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateNamespace, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateIcon16Path, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateIcon32Path, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateCssFileName, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateIsCssImportant, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.uiGenerateHandlerPath, 1, 5);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(7, 37);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(546, 150);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Handler Path:";
            // 
            // Label2
            // 
            this.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(3, 6);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(103, 13);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Project Namespace:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Icon16 Path:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Icon32 Path:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Css Filename:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 106);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Add \"IsImportant\":";
            // 
            // uiGenerateNamespace
            // 
            this.uiGenerateNamespace.Location = new System.Drawing.Point(130, 3);
            this.uiGenerateNamespace.Name = "uiGenerateNamespace";
            this.uiGenerateNamespace.Size = new System.Drawing.Size(181, 20);
            this.uiGenerateNamespace.TabIndex = 8;
            // 
            // uiGenerateIcon16Path
            // 
            this.uiGenerateIcon16Path.Location = new System.Drawing.Point(130, 28);
            this.uiGenerateIcon16Path.Name = "uiGenerateIcon16Path";
            this.uiGenerateIcon16Path.Size = new System.Drawing.Size(413, 20);
            this.uiGenerateIcon16Path.TabIndex = 9;
            // 
            // uiGenerateIcon32Path
            // 
            this.uiGenerateIcon32Path.Location = new System.Drawing.Point(130, 53);
            this.uiGenerateIcon32Path.Name = "uiGenerateIcon32Path";
            this.uiGenerateIcon32Path.Size = new System.Drawing.Size(413, 20);
            this.uiGenerateIcon32Path.TabIndex = 10;
            // 
            // uiGenerateCssFileName
            // 
            this.uiGenerateCssFileName.Location = new System.Drawing.Point(130, 78);
            this.uiGenerateCssFileName.Name = "uiGenerateCssFileName";
            this.uiGenerateCssFileName.Size = new System.Drawing.Size(181, 20);
            this.uiGenerateCssFileName.TabIndex = 11;
            // 
            // uiGenerateIsCssImportant
            // 
            this.uiGenerateIsCssImportant.AutoSize = true;
            this.uiGenerateIsCssImportant.Location = new System.Drawing.Point(130, 103);
            this.uiGenerateIsCssImportant.Name = "uiGenerateIsCssImportant";
            this.uiGenerateIsCssImportant.Size = new System.Drawing.Size(15, 14);
            this.uiGenerateIsCssImportant.TabIndex = 12;
            this.uiGenerateIsCssImportant.UseVisualStyleBackColor = true;
            // 
            // uiGenerateHandlerPath
            // 
            this.uiGenerateHandlerPath.Location = new System.Drawing.Point(130, 128);
            this.uiGenerateHandlerPath.Name = "uiGenerateHandlerPath";
            this.uiGenerateHandlerPath.Size = new System.Drawing.Size(181, 20);
            this.uiGenerateHandlerPath.TabIndex = 13;
            // 
            // uiGenerate
            // 
            this.uiGenerate.Location = new System.Drawing.Point(478, 195);
            this.uiGenerate.Name = "uiGenerate";
            this.uiGenerate.Size = new System.Drawing.Size(75, 23);
            this.uiGenerate.TabIndex = 0;
            this.uiGenerate.Text = "Generate";
            this.uiGenerate.UseVisualStyleBackColor = true;
            this.uiGenerate.Click += new System.EventHandler(this.uiGenerate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.uiWorkingDirectoryHelp);
            this.groupBox1.Controls.Add(this.uiWorkingDirectoryMessage);
            this.groupBox1.Controls.Add(this.uiWorkingDirectoryValidate);
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(559, 134);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Output";
            // 
            // uiWorkingDirectoryHelp
            // 
            this.uiWorkingDirectoryHelp.AutoSize = true;
            this.uiWorkingDirectoryHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiWorkingDirectoryHelp.Location = new System.Drawing.Point(4, 16);
            this.uiWorkingDirectoryHelp.Name = "uiWorkingDirectoryHelp";
            this.uiWorkingDirectoryHelp.Size = new System.Drawing.Size(165, 17);
            this.uiWorkingDirectoryHelp.TabIndex = 3;
            this.uiWorkingDirectoryHelp.Text = "[uiWorkingDirectoryHelp]";
            // 
            // uiWorkingDirectoryMessage
            // 
            this.uiWorkingDirectoryMessage.AutoSize = true;
            this.uiWorkingDirectoryMessage.Location = new System.Drawing.Point(4, 114);
            this.uiWorkingDirectoryMessage.Name = "uiWorkingDirectoryMessage";
            this.uiWorkingDirectoryMessage.Size = new System.Drawing.Size(146, 13);
            this.uiWorkingDirectoryMessage.TabIndex = 2;
            this.uiWorkingDirectoryMessage.Text = "[uiWorkingDirectoryMessage]";
            // 
            // uiWorkingDirectoryValidate
            // 
            this.uiWorkingDirectoryValidate.Location = new System.Drawing.Point(478, 104);
            this.uiWorkingDirectoryValidate.Name = "uiWorkingDirectoryValidate";
            this.uiWorkingDirectoryValidate.Size = new System.Drawing.Size(75, 23);
            this.uiWorkingDirectoryValidate.TabIndex = 1;
            this.uiWorkingDirectoryValidate.Text = "Validate";
            this.uiWorkingDirectoryValidate.UseVisualStyleBackColor = true;
            this.uiWorkingDirectoryValidate.Click += new System.EventHandler(this.uiWorkingDirectoryValidate_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 446F));
            this.tableLayoutPanel1.Controls.Add(this.uiWorkingDirectoryPath, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(7, 69);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(546, 25);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // uiWorkingDirectoryPath
            // 
            this.uiWorkingDirectoryPath.Location = new System.Drawing.Point(103, 3);
            this.uiWorkingDirectoryPath.Name = "uiWorkingDirectoryPath";
            this.uiWorkingDirectoryPath.Size = new System.Drawing.Size(440, 20);
            this.uiWorkingDirectoryPath.TabIndex = 1;
            this.uiWorkingDirectoryPath.TextChanged += new System.EventHandler(this.uiWorkingDirectoryPath_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Output Directory:";
            // 
            // uiReset
            // 
            this.uiReset.Location = new System.Drawing.Point(478, 8);
            this.uiReset.Name = "uiReset";
            this.uiReset.Size = new System.Drawing.Size(75, 23);
            this.uiReset.TabIndex = 7;
            this.uiReset.Text = "Reset";
            this.uiReset.UseVisualStyleBackColor = true;
            this.uiReset.Click += new System.EventHandler(this.uiReset_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 562);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button uiSynchronize;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox uiSyncSourceDirectoryPath;
        private System.Windows.Forms.TextBox uiSyncWithDirectoryPath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Button uiGenerate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label uiWorkingDirectoryHelp;
        private System.Windows.Forms.Label uiWorkingDirectoryMessage;
        private System.Windows.Forms.Button uiWorkingDirectoryValidate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox uiWorkingDirectoryPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label uiSyncIconHelp;
        private System.Windows.Forms.Label uiSyncMessage;
        private System.Windows.Forms.Label uiGenerateMessage;
        private System.Windows.Forms.Label uiGenerateHelp;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox uiGenerateNamespace;
        private System.Windows.Forms.TextBox uiGenerateIcon16Path;
        private System.Windows.Forms.TextBox uiGenerateIcon32Path;
        private System.Windows.Forms.TextBox uiGenerateCssFileName;
        private System.Windows.Forms.CheckBox uiGenerateIsCssImportant;
        private System.Windows.Forms.TextBox uiGenerateHandlerPath;
        private System.Windows.Forms.Button uiReset;
    }
}
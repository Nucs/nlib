﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System.IO;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class SynchronizeIcon
    {
        public void Synchronize()
        {
            var workingDirectory = new DirectoryInfo(WorkingDirectory.DirectoryPath);
            var sourceDirectory = new DirectoryInfo(IconSourceDirectoryPath);
            var withDirectory = new DirectoryInfo(WithDirectoryPath);

            workingDirectory.Clear();

            FileInfo[] files = sourceDirectory.GetFiles("*.*", SearchOption.TopDirectoryOnly);
            foreach (FileInfo file in files)
            {
                // Get the path in the "WithDirectory"
                string path = file.FullName.Replace(sourceDirectory.FullName, withDirectory.FullName);
                var withDirectoryFile = new FileInfo(path);

                if (withDirectoryFile.Exists)
                {
                    // If the file exists, copy the file in the working directory
                    string newPath = file.FullName.Replace(sourceDirectory.FullName, workingDirectory.FullName);
                    withDirectoryFile.CopyTo(newPath);
                }
            }
        }
    }
}
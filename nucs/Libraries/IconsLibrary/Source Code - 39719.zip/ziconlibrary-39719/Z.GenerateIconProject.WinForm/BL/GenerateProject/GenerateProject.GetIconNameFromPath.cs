﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System.Globalization;
using System.IO;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public string GetIconNameFromPath(FileInfo file)
        {
            string fileName = file.Name;
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;

            string name = fileName.Split('.')[0];
            string suffixe = "";
            if (name.EndsWith("_"))
            {
                suffixe = "_";
            }
            name = textInfo.ToTitleCase(name.Replace("_", " ").Replace(")", " ").Replace("(", " ")).Replace(" ", "");
            if (char.IsNumber(name[0]))
            {
                name = "_" + name;
            }
            return name + suffixe;
        }
    }
}
﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public string GenerateIconEnum()
        {
            var sb = new StringBuilder();

            var dic = new Dictionary<string, string>();
            if (Icon16DirectoryPath != "")
            {
                sb.Append(GenerateIconEnum(new DirectoryInfo(Icon16DirectoryPath), "Icon16", dic));
            }

            if (Icon32DirectoryPath != "")
            {
                sb.Append(GenerateIconEnum(new DirectoryInfo(Icon32DirectoryPath), "Icon32", dic));
            }

            return sb.ToString();
        }

        private string GenerateIconEnum(DirectoryInfo dir, string iconSize, Dictionary<string, string> dict)
        {
            string template = "        [Description(\"@(Model.FileName)\")]" + Environment.NewLine + "        @(Model.IconName),";
            var sb = new StringBuilder();

            foreach (FileInfo file in dir.GetFiles())
            {
                if (!dict.ContainsKey(file.Name))
                {
                    string s = template;
                    s = s.Replace("@(Model.FileName)", file.Name);
                    s = s.Replace("@(Model.IconName)", GetIconNameFromPath(file));

                    sb.AppendLine(s);
                    dict.Add(file.Name, file.Name);
                }
            }
            return sb.ToString();
        }
    }
}
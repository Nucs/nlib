﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System;
using System.IO;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public Result IsValid()
        {
            if (Icon16DirectoryPath != "")
            {
                try
                {
                    if (!new DirectoryInfo(Icon16DirectoryPath).Exists)
                    {
                        return new Result(false, My.Message.Error.EM202);
                    }
                }
                catch (Exception)
                {
                    return new Result(false, My.Message.Error.EM202);
                }
            }

            if (Icon32DirectoryPath != "")
            {
                try
                {
                    if (!new DirectoryInfo(Icon32DirectoryPath).Exists)
                    {
                        return new Result(false, My.Message.Error.EM203);
                    }
                }
                catch (Exception)
                {
                    return new Result(false, My.Message.Error.EM203);
                }
            }

            if (Icon16DirectoryPath == "" || Icon32DirectoryPath == "")
            {
                return new Result(false, My.Message.Error.EM204);
            }

            if (Namespace == "")
            {
                return new Result(false, My.Message.Error.EM205);
            }

            if (CssFileName == "")
            {
                return new Result(false, My.Message.Error.EM206);
            }

            if (HandlerPath == "")
            {
                return new Result(false, My.Message.Error.EM207);
            }

            return true;
        }
    }
}
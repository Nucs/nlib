﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System.IO;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public void Generate()
        {
            // Get directory
            var workingDirectory = new DirectoryInfo(WorkingDirectory.DirectoryPath);
            var templateDirectory = new DirectoryInfo(My.TemplateIconProject);
            var workingIcon16Directory = new DirectoryInfo(Path.Combine(workingDirectory.FullName, Namespace, "Icon16"));
            var workingIcon32Directory = new DirectoryInfo(Path.Combine(workingDirectory.FullName, Namespace, "Icon32"));

            // Clear the working directory
            workingDirectory.Clear();

            // Create icon directory
            Directory.CreateDirectory(workingIcon16Directory.FullName);
            Directory.CreateDirectory(workingIcon32Directory.FullName);

            // Generate template
            string iconEnum = GenerateIconEnum();
            string css = GenerateCss();
            string embedded = GenerateEmbedded();
            string projectEmbedded = GenerateProjectEmbedded();

            // Get files
            FileInfo[] files = templateDirectory.GetFiles("*.*", SearchOption.AllDirectories);
            foreach (FileInfo file in files)
            {
                string newFileName;
                if (file.Name == "readme.txt.txt")
                {
                    newFileName = file.FullName.Replace(templateDirectory.FullName, workingDirectory.FullName).Replace("readme.txt.txt", "readme.txt");
                }
                else
                {
                    newFileName = file.FullName.Replace(templateDirectory.FullName, workingDirectory.FullName).Replace(".txt", "");
                }


                // Replace template field in file name
                newFileName = newFileName.Replace("@(Model.Namespace)", Namespace);
                newFileName = newFileName.Replace("@(Model.CssFileName)", CssFileName);
                var newFile = new FileInfo(newFileName);

                // Ensure the target directory exists
                Directory.CreateDirectory(newFile.Directory.FullName);

                // Replace template field in file text
                string text = file.ReadToEnd();
                text = text.Replace("@(Model.Namespace)", Namespace);
                text = text.Replace("@(Model.HandlerPath)", HandlerPath);
                text = text.Replace("@(Model.CssFileName)", CssFileName);
                text = text.Replace("@(Model.IconEnum)", iconEnum);
                text = text.Replace("@(Model.Css)", css);
                text = text.Replace("@(Model.Embedded)", embedded);
                text = text.Replace("@(Model.ProjectEmbedded)", projectEmbedded);
                text.SaveAs(newFileName);
            }

            if (Icon16DirectoryPath != "")
            {
                // Copy all icon 16x16
                var icon16Directory = new DirectoryInfo(Icon16DirectoryPath);
                foreach (FileInfo file in icon16Directory.GetFiles())
                {
                    string newFile = file.FullName.Replace(icon16Directory.FullName, workingIcon16Directory.FullName);
                    file.CopyTo(newFile);
                }
            }

            if (Icon32DirectoryPath != "")
            {
                // Copy all icon 32x32
                var icon32Directory = new DirectoryInfo(Icon32DirectoryPath);
                foreach (FileInfo file in icon32Directory.GetFiles())
                {
                    string newFile = file.FullName.Replace(icon32Directory.FullName, workingIcon32Directory.FullName);
                    file.CopyTo(newFile);
                }
            }
        }
    }
}
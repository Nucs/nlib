﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public ListCompareResult<KeyValuePair<string, FileInfo>, KeyValuePair<string, FileInfo>> IsSynchro()
        {
            Dictionary<string, FileInfo> dict16 = Icon16DirectoryPath.ToDirectoryInfo().GetFiles().ToDictionary(info => info.Name);
            Dictionary<string, FileInfo> dict32 = Icon32DirectoryPath.ToDirectoryInfo().GetFiles().ToDictionary(info => info.Name);

            var dictionaryCompare = new DictionaryCompare<string, FileInfo, FileInfo>(dict16, dict32);
            dictionaryCompare.Compare();

            return dictionaryCompare.ListCompareResult;
        }
    }
}
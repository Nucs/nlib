﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System.IO;
using System.Text;

namespace Z.GenerateIconProject.WinForm.BL
{
    public partial class GenerateProject
    {
        public string GenerateProjectEmbedded()
        {
            var sb = new StringBuilder();

            if (Icon16DirectoryPath != "")
            {
                sb.Append(GenerateProjectEmbedded(new DirectoryInfo(Icon16DirectoryPath), "Icon16"));
            }

            if (Icon32DirectoryPath != "")
            {
                sb.Append(GenerateProjectEmbedded(new DirectoryInfo(Icon32DirectoryPath), "Icon32"));
            }

            return sb.ToString();
        }

        private string GenerateProjectEmbedded(DirectoryInfo dir, string iconSize)
        {
            const string template = "    <EmbeddedResource Include=\"@(Model.IconSize)\\@(Model.FileName)\" />";
            var sb = new StringBuilder();

            foreach (FileInfo file in dir.GetFiles())
            {
                string s = template;
                s = s.Replace("@(Model.IconSize)", iconSize);
                s = s.Replace("@(Model.FileName)", file.Name);

                sb.AppendLine(s);
            }
            return sb.ToString();
        }
    }
}
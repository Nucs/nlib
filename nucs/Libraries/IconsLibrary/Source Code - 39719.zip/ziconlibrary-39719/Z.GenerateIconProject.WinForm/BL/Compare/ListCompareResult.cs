﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System;
using System.Collections.Generic;

namespace Z
{
    /// <summary>
    ///     C# object which old the resulst of a ListCompare
    /// </summary>
    /// <typeparam name="T1">T1 object type</typeparam>
    /// <typeparam name="T2">T2 object type</typeparam>
    public class ListCompareResult<T1, T2>
    {
        /// <summary>
        ///     Item list from list 1 & list 2 where item are equal. Careful the result is not distinct
        /// </summary>
        public List<Tuple<T1, T2>> ItemListEqual;

        /// <summary>
        ///     Item list from the list 1 which exist in list 2
        /// </summary>
        public List<T1> ItemListEqualLeft;

        /// <summary>
        ///     Item list from the list 2 which exist in list 1
        /// </summary>
        public List<T2> ItemListEqualRight;

        /// <summary>
        ///     Item list from the list 1 which doesn't exists in the list 2
        /// </summary>
        public List<T1> ItemListLeft;

        /// <summary>
        ///     Item list from the list 2 which doesn't exists in the list 1
        /// </summary>
        public List<T2> ItemListRight;
    }
}
﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

namespace Z.GenerateIconProject.WinForm.BL
{
    public class Result
    {
        public string Message;
        public bool Value;

        public Result(bool value)
        {
            Value = value;
        }

        public Result(bool value, string message)
        {
            Value = value;
            Message = message;
        }

        public static implicit operator bool(Result @this)
        {
            return @this.Value;
        }

        public static implicit operator Result(bool value)
        {
            return new Result(value);
        }
    }
}
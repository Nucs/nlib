﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

namespace Z.GenerateIconProject.WinForm
{
    public class My
    {
        public const string TemplateIconProject = "TemplateIconProject";

        public class Message
        {
            public class Error
            {
                public const string EM001 = "A general error occurred.";
                public const string EM002 = "Invalid directory name.";
                public const string EM101 = "A general error occurred.";
                public const string EM102 = "The “Source” directory must exists.";
                public const string EM103 = "The “With” directory must exists.";
                public const string EM201 = "A general error occurred.";
                public const string EM202 = "The Icon16 Directory must exists or be empty.";
                public const string EM203 = "The Icon32 Directory must exists or be empty.";
                public const string EM204 = "The Icon16 and Icon32 cannot be both empty.";
                public const string EM205 = "The namespace cannot be empty.";
                public const string EM206 = "The css file name cannot be empty.";
                public const string EM207 = "The handler path cannot be empty.";
            }

            public class Success
            {
                public const string SM001 = "The working directory is valid.";
                public const string SM101 = "The icon directory have been synchronized in your output directory.";
                public const string SM201 = "The project have been generated in your output directory.";
            }

            public class Text
            {
                public static string TM001 = "Specify in which directory you want your files to be generated.\r\nIf the directory doesn’t end with “IconWorkingDirectory”, the directory will be \r\nadded at the end of your path.";
                public static string TM002 = "In this example, we assume you have filtered all your icon 32x32 in a Icon32 folder\r\nand want to create an Icon16 folder from the full fatcow icon set 16x16.";
                public static string TM003 = "Specify your configuration to generate the C# icon project. ";
            }
        }
    }
}
﻿// Code are under MIT License
// http://ziconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://jonathanmagnan.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Z.GenerateIconProject.WinForm.BL;
using Z.GenerateIconProject.WinForm.Properties;

namespace Z.GenerateIconProject.WinForm
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            StartPosition = FormStartPosition.CenterScreen;

            uiWorkingDirectoryHelp.Text = My.Message.Text.TM001;
            uiWorkingDirectoryMessage.Text = "";
            uiSyncIconHelp.Text = My.Message.Text.TM002;
            uiSyncMessage.Text = "";
            uiGenerateHelp.Text = My.Message.Text.TM003;
            uiGenerateMessage.Text = "";

            uiWorkingDirectoryPath.Text = Settings.Default.WorkingDirectoryPath;
            uiSyncSourceDirectoryPath.Text = Settings.Default.SyncSourceDirectoryPath;
            uiSyncWithDirectoryPath.Text = Settings.Default.SyncWithDirectoryPath;
            uiGenerateNamespace.Text = Settings.Default.GenerateNamespace;
            uiGenerateIcon16Path.Text = Settings.Default.GenerateIcon16Path;
            uiGenerateIcon32Path.Text = Settings.Default.GenerateIcon32Path;
            uiGenerateCssFileName.Text = Settings.Default.GenerateCssFileName;
            uiGenerateIsCssImportant.Checked = Settings.Default.GenerateIsCssImportant;
            uiGenerateHandlerPath.Text = Settings.Default.GenerateHandlerPath;

            ToggleAllAction(false);

            if (uiWorkingDirectoryPath.Text != "")
            {
                uiWorkingDirectoryValidate_Click(null, null);
            }
        }

        private void uiWorkingDirectoryValidate_Click(object sender, EventArgs e)
        {
            var workingDirectory = new WorkingDirectory {DirectoryPath = uiWorkingDirectoryPath.Text};
            Result result = workingDirectory.ValidateAndCreate();

            if (result)
            {
                uiWorkingDirectoryPath.Text = workingDirectory.DirectoryPath;
                ToggleAllAction(result);
                uiWorkingDirectoryMessage.Text = My.Message.Success.SM001;
                uiWorkingDirectoryMessage.ForeColor = Color.Green;

                Settings.Default.WorkingDirectoryPath = uiWorkingDirectoryPath.Text;
                Settings.Default.Save();
            }
            else
            {
                ToggleAllAction(result);
                uiWorkingDirectoryMessage.Text = result.Message;
                uiWorkingDirectoryMessage.ForeColor = Color.Red;
            }
        }

        public void ToggleAllAction(bool enable)
        {
            uiSynchronize.Enabled = enable;
            uiGenerate.Enabled = enable;
        }

        private void uiWorkingDirectoryPath_TextChanged(object sender, EventArgs e)
        {
            ToggleAllAction(false);
        }

        private void uiSynchronize_Click(object sender, EventArgs e)
        {
            var synchronize = new SynchronizeIcon
            {
                WorkingDirectory = new WorkingDirectory {DirectoryPath = uiWorkingDirectoryPath.Text},
                IconSourceDirectoryPath = uiSyncSourceDirectoryPath.Text,
                WithDirectoryPath = uiSyncWithDirectoryPath.Text
            };

            Result result = synchronize.IsValid();
            if (result)
            {
                try
                {
                    synchronize.Synchronize();
                    uiSyncMessage.Text = My.Message.Success.SM101;
                    uiSyncMessage.ForeColor = Color.Green;
                    Settings.Default.SyncSourceDirectoryPath = uiSyncSourceDirectoryPath.Text;
                    Settings.Default.SyncWithDirectoryPath = uiSyncWithDirectoryPath.Text;
                    Settings.Default.Save();
                }
                catch
                {
                    uiSyncMessage.Text = My.Message.Error.EM101;
                    uiSyncMessage.ForeColor = Color.Red;
                }
            }
            else
            {
                uiSyncMessage.Text = result.Message;
                uiSyncMessage.ForeColor = Color.Red;
            }
        }

        private void uiGenerate_Click(object sender, EventArgs e)
        {
            var generate = new GenerateProject
            {
                WorkingDirectory = new WorkingDirectory {DirectoryPath = uiWorkingDirectoryPath.Text},
                Namespace = uiGenerateNamespace.Text,
                Icon16DirectoryPath = uiGenerateIcon16Path.Text,
                Icon32DirectoryPath = uiGenerateIcon32Path.Text,
                CssFileName = uiGenerateCssFileName.Text,
                IsCssImportant = uiGenerateIsCssImportant.Checked,
                HandlerPath = uiGenerateHandlerPath.Text
            };

            Result result = generate.IsValid();
            if (result)
            {
                try
                {
                    ListCompareResult<KeyValuePair<string, FileInfo>, KeyValuePair<string, FileInfo>> compareResult = generate.IsSynchro();

                    if (compareResult.ItemListLeft.Count > 0 || compareResult.ItemListRight.Count > 0)
                    {
                        var sb = new StringBuilder();
                        sb.AppendLine("Your Icon directory are not synchronized, are you sure you want to continue?");
                        sb.AppendLine();
                        sb.AppendLine("Icon16:");
                        foreach (var item in compareResult.ItemListLeft)
                        {
                            sb.AppendLine("- " + item.Value.Name);
                        }
                        sb.AppendLine();
                        sb.AppendLine("Icon32:");
                        foreach (var item in compareResult.ItemListRight)
                        {
                            sb.AppendLine("- " + item.Value.Name);
                        }
                        DialogResult sResult = MessageBox.Show(sb.ToString(), "Directory not synchronized", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (sResult == DialogResult.No)
                        {
                            uiGenerateMessage.Text = "Generation cancelled";
                            uiGenerateMessage.ForeColor = Color.Red;
                            return;
                        }
                    }

                    MessageBox.Show("Generating may take several seconds...", "Generating...", MessageBoxButtons.OK);
                    generate.Generate();
                    uiGenerateMessage.Text = My.Message.Success.SM201;
                    uiGenerateMessage.ForeColor = Color.Green;

                    Settings.Default.GenerateNamespace = uiGenerateNamespace.Text;
                    Settings.Default.GenerateIcon16Path = uiGenerateIcon16Path.Text;
                    Settings.Default.GenerateIcon32Path = uiGenerateIcon32Path.Text;
                    Settings.Default.GenerateCssFileName = uiGenerateCssFileName.Text;
                    Settings.Default.GenerateIsCssImportant = uiGenerateIsCssImportant.Checked;
                    Settings.Default.GenerateHandlerPath = uiGenerateHandlerPath.Text;
                    Settings.Default.Save();
                }
                catch (Exception ex)
                {
                    uiGenerateMessage.Text = My.Message.Error.EM101 + ":" + ex.Message;
                    uiGenerateMessage.ForeColor = Color.Red;
                }
            }
            else
            {
                uiGenerateMessage.Text = result.Message;
                uiGenerateMessage.ForeColor = Color.Red;
            }
        }

        private void uiReset_Click(object sender, EventArgs e)
        {
            uiGenerateNamespace.Text = "Z.IconLibrary";
            uiGenerateIcon16Path.Text = "";
            uiGenerateIcon32Path.Text = "";
            uiGenerateCssFileName.Text = "z-icon.css";
            uiGenerateIsCssImportant.Checked = true;
            uiGenerateHandlerPath.Text = "z.axd";
        }
    }
}
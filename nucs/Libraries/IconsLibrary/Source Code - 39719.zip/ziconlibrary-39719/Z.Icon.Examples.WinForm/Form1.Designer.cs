﻿namespace Z.Examples.WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.uiIcon = new System.Windows.Forms.ComboBox();
            this.uiDynamicImage16 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.uiDynamicImage32 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.uiDynamicIcon16 = new System.Windows.Forms.PictureBox();
            this.uiDynamicIcon32 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.uiDynamicBitmap16 = new System.Windows.Forms.PictureBox();
            this.uiDynamicBitmap32 = new System.Windows.Forms.PictureBox();
            this.uiDynamicStream16 = new System.Windows.Forms.PictureBox();
            this.uiDynamicStream32 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.uiStream32 = new System.Windows.Forms.PictureBox();
            this.uiStream16 = new System.Windows.Forms.PictureBox();
            this.uiBitmap32 = new System.Windows.Forms.PictureBox();
            this.uiBitmap16 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.uiImage16 = new System.Windows.Forms.PictureBox();
            this.uiImage32 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.uiIcon16 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.uiIcon32 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicImage16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicImage32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicIcon16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicIcon32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicBitmap16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicBitmap32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicStream16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicStream32)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uiStream32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiStream16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiBitmap32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiBitmap16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImage16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImage32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiIcon16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiIcon32)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(326, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(358, 355);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dynamic Examples";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.uiIcon, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicImage16, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicImage32, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicIcon16, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicIcon32, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicBitmap16, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicBitmap32, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicStream16, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.uiDynamicStream32, 1, 8);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(7, 20);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(345, 325);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 275);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "Stream 32x32 (as Image)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose Icon:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Image 16x16";
            // 
            // uiIcon
            // 
            this.uiIcon.FormattingEnabled = true;
            this.uiIcon.Location = new System.Drawing.Point(153, 3);
            this.uiIcon.Name = "uiIcon";
            this.uiIcon.Size = new System.Drawing.Size(178, 21);
            this.uiIcon.TabIndex = 2;
            this.uiIcon.SelectedIndexChanged += new System.EventHandler(this.uiIcon_SelectedIndexChanged);
            // 
            // uiDynamicImage16
            // 
            this.uiDynamicImage16.Location = new System.Drawing.Point(153, 28);
            this.uiDynamicImage16.Name = "uiDynamicImage16";
            this.uiDynamicImage16.Size = new System.Drawing.Size(100, 19);
            this.uiDynamicImage16.TabIndex = 3;
            this.uiDynamicImage16.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Image 32x32";
            // 
            // uiDynamicImage32
            // 
            this.uiDynamicImage32.Location = new System.Drawing.Point(153, 53);
            this.uiDynamicImage32.Name = "uiDynamicImage32";
            this.uiDynamicImage32.Size = new System.Drawing.Size(100, 44);
            this.uiDynamicImage32.TabIndex = 5;
            this.uiDynamicImage32.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Icon 16x16";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Icon 32x32";
            // 
            // uiDynamicIcon16
            // 
            this.uiDynamicIcon16.Location = new System.Drawing.Point(153, 103);
            this.uiDynamicIcon16.Name = "uiDynamicIcon16";
            this.uiDynamicIcon16.Size = new System.Drawing.Size(100, 19);
            this.uiDynamicIcon16.TabIndex = 8;
            this.uiDynamicIcon16.TabStop = false;
            // 
            // uiDynamicIcon32
            // 
            this.uiDynamicIcon32.Location = new System.Drawing.Point(153, 128);
            this.uiDynamicIcon32.Name = "uiDynamicIcon32";
            this.uiDynamicIcon32.Size = new System.Drawing.Size(100, 44);
            this.uiDynamicIcon32.TabIndex = 9;
            this.uiDynamicIcon32.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 175);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "Bitmap 16x16";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 200);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Bitmap 32x32";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 250);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "Stream 16x16 (as Image)";
            // 
            // uiDynamicBitmap16
            // 
            this.uiDynamicBitmap16.Location = new System.Drawing.Point(153, 178);
            this.uiDynamicBitmap16.Name = "uiDynamicBitmap16";
            this.uiDynamicBitmap16.Size = new System.Drawing.Size(100, 19);
            this.uiDynamicBitmap16.TabIndex = 14;
            this.uiDynamicBitmap16.TabStop = false;
            // 
            // uiDynamicBitmap32
            // 
            this.uiDynamicBitmap32.Location = new System.Drawing.Point(153, 203);
            this.uiDynamicBitmap32.Name = "uiDynamicBitmap32";
            this.uiDynamicBitmap32.Size = new System.Drawing.Size(100, 44);
            this.uiDynamicBitmap32.TabIndex = 15;
            this.uiDynamicBitmap32.TabStop = false;
            // 
            // uiDynamicStream16
            // 
            this.uiDynamicStream16.Location = new System.Drawing.Point(153, 253);
            this.uiDynamicStream16.Name = "uiDynamicStream16";
            this.uiDynamicStream16.Size = new System.Drawing.Size(100, 19);
            this.uiDynamicStream16.TabIndex = 16;
            this.uiDynamicStream16.TabStop = false;
            // 
            // uiDynamicStream32
            // 
            this.uiDynamicStream32.Location = new System.Drawing.Point(153, 278);
            this.uiDynamicStream32.Name = "uiDynamicStream32";
            this.uiDynamicStream32.Size = new System.Drawing.Size(100, 44);
            this.uiDynamicStream32.TabIndex = 17;
            this.uiDynamicStream32.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel3);
            this.groupBox3.Location = new System.Drawing.Point(12, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(294, 355);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Static Examples";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.uiStream32, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.uiStream16, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.uiBitmap32, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.uiBitmap16, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.uiImage16, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.uiImage32, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.uiIcon16, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.uiIcon32, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 7);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(7, 20);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 8;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(282, 300);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // uiStream32
            // 
            this.uiStream32.Location = new System.Drawing.Point(153, 253);
            this.uiStream32.Name = "uiStream32";
            this.uiStream32.Size = new System.Drawing.Size(100, 44);
            this.uiStream32.TabIndex = 15;
            this.uiStream32.TabStop = false;
            // 
            // uiStream16
            // 
            this.uiStream16.Location = new System.Drawing.Point(153, 228);
            this.uiStream16.Name = "uiStream16";
            this.uiStream16.Size = new System.Drawing.Size(100, 19);
            this.uiStream16.TabIndex = 14;
            this.uiStream16.TabStop = false;
            // 
            // uiBitmap32
            // 
            this.uiBitmap32.Location = new System.Drawing.Point(153, 178);
            this.uiBitmap32.Name = "uiBitmap32";
            this.uiBitmap32.Size = new System.Drawing.Size(100, 44);
            this.uiBitmap32.TabIndex = 13;
            this.uiBitmap32.TabStop = false;
            // 
            // uiBitmap16
            // 
            this.uiBitmap16.Location = new System.Drawing.Point(153, 153);
            this.uiBitmap16.Name = "uiBitmap16";
            this.uiBitmap16.Size = new System.Drawing.Size(100, 19);
            this.uiBitmap16.TabIndex = 12;
            this.uiBitmap16.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Image 16x16";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Image 32x32";
            // 
            // uiImage16
            // 
            this.uiImage16.Location = new System.Drawing.Point(153, 3);
            this.uiImage16.Name = "uiImage16";
            this.uiImage16.Size = new System.Drawing.Size(100, 19);
            this.uiImage16.TabIndex = 2;
            this.uiImage16.TabStop = false;
            // 
            // uiImage32
            // 
            this.uiImage32.Location = new System.Drawing.Point(153, 28);
            this.uiImage32.Name = "uiImage32";
            this.uiImage32.Size = new System.Drawing.Size(100, 44);
            this.uiImage32.TabIndex = 3;
            this.uiImage32.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Icon 16x16";
            // 
            // uiIcon16
            // 
            this.uiIcon16.Location = new System.Drawing.Point(153, 78);
            this.uiIcon16.Name = "uiIcon16";
            this.uiIcon16.Size = new System.Drawing.Size(100, 19);
            this.uiIcon16.TabIndex = 6;
            this.uiIcon16.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Icon 32x32";
            // 
            // uiIcon32
            // 
            this.uiIcon32.Location = new System.Drawing.Point(153, 103);
            this.uiIcon32.Name = "uiIcon32";
            this.uiIcon32.Size = new System.Drawing.Size(100, 44);
            this.uiIcon32.TabIndex = 7;
            this.uiIcon32.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Bitmap 16x16";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 175);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Bitmap 32x32";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 225);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Stream 16x16 (as Image)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 250);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "Stream 32x32 (as Image)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 378);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "C# - Icon Library Examples";
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicImage16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicImage32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicIcon16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicIcon32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicBitmap16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicBitmap32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicStream16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiDynamicStream32)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uiStream32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiStream16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiBitmap32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiBitmap16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImage16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImage32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiIcon16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiIcon32)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox uiIcon;
        private System.Windows.Forms.PictureBox uiDynamicImage16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox uiImage16;
        private System.Windows.Forms.PictureBox uiImage32;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox uiDynamicImage32;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox uiIcon16;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox uiIcon32;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox uiDynamicIcon16;
        private System.Windows.Forms.PictureBox uiDynamicIcon32;
        private System.Windows.Forms.PictureBox uiStream32;
        private System.Windows.Forms.PictureBox uiStream16;
        private System.Windows.Forms.PictureBox uiBitmap32;
        private System.Windows.Forms.PictureBox uiBitmap16;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox uiDynamicBitmap16;
        private System.Windows.Forms.PictureBox uiDynamicBitmap32;
        private System.Windows.Forms.PictureBox uiDynamicStream16;
        private System.Windows.Forms.PictureBox uiDynamicStream32;
    }
}


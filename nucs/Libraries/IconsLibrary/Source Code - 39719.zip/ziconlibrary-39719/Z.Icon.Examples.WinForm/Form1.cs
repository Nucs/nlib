﻿// Code are under MIT License
// http://ciconlibrary.codeplex.com/license
// Copyright (c) 2014 Jonathan Magnan. All rights reserved.
// http://www.zzzportal.com
// 
// All icons are licensed under a Creative Commons Attribution 3.0 License.
// http://creativecommons.org/licenses/by/3.0/us/
// Copyright 2009-2013 FatCow Web Hosting. All rights reserved.
// http://www.fatcow.com/free-icons

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Icon = Z.IconLibrary.Icon;

namespace Z.Examples.WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            uiIcon.DataSource = Enum.GetValues(typeof (Icon));

            // SET static icon
            uiImage16.Image = IconLibrary.Icon.Accept.GetImage16();
            uiImage32.Image = IconLibrary.Icon.Accept.GetImage32();
            uiIcon16.Image = IconLibrary.Icon.Accept.GetIcon16().ToBitmap();
            uiIcon32.Image = IconLibrary.Icon.Accept.GetIcon32().ToBitmap();
            uiBitmap16.Image = IconLibrary.Icon.Accept.GetBitmap16();
            uiBitmap32.Image = IconLibrary.Icon.Accept.GetBitmap32();
            using (Stream stream = IconLibrary.Icon.Accept.GetStream16())
            {
                uiStream16.Image = new Bitmap(stream);
            }
            using (Stream stream = IconLibrary.Icon.Accept.GetStream32())
            {
                uiStream32.Image = new Bitmap(stream);
            }
        }

        private void uiIcon_SelectedIndexChanged(object sender, EventArgs e)
        {
            var dynamicIcon = (Icon) Enum.Parse(typeof (Icon), uiIcon.SelectedValue.ToString());
            uiDynamicImage16.Image = dynamicIcon.GetImage16();
            uiDynamicImage32.Image = dynamicIcon.GetImage32();
            uiDynamicIcon16.Image = dynamicIcon.GetIcon16().ToBitmap();
            uiDynamicIcon32.Image = dynamicIcon.GetIcon32().ToBitmap();
            uiDynamicBitmap16.Image = dynamicIcon.GetBitmap16();
            uiDynamicBitmap32.Image = dynamicIcon.GetBitmap32();
            using (Stream stream = dynamicIcon.GetStream16())
            {
                uiDynamicStream16.Image = new Bitmap(stream);
            }
            using (Stream stream = dynamicIcon.GetStream32())
            {
                uiDynamicStream32.Image = new Bitmap(stream);
            }
        }
    }
}